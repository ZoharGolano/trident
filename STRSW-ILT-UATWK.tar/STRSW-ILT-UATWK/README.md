# STRSW-ILT-UATWK
Using Astra Trident with Kubernetes <br />
Version 1.0 (March 2022) <br />
Kubernetes v1.23  <br />
WeaveNet 2.8.1 <br />
Docker 20.10.12 <br />
ONTAP 9.9.1 <br />
Astra Trident 22.01.0 <br />

